function overlayOn() {
  document.getElementById("overlay").classList.remove("hidden");
}

function overlayOff() {
  document.getElementById("overlay").classList.add("hidden");
}